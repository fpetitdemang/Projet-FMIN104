/*
 * Observer.cpp
 *
 *  Created on: 8 déc. 2012
 *      Author: franck
 */

#include "Observer.h"
#include <cstdio>

Observer::Observer() {
}

Observer::~Observer() {
	// TODO Auto-generated destructor stub
}

